Web UI (copy buttons): https://ziad.net.pl/multicraft-we-greek-temple/

QUICK START — Greek Temple v2 (baked Joke-style packs)
=======================================================
Commands use the invite WorldEdit form:
  /fp set1 X Y Z
  /fp set2 X Y Z
  /s amethyst_geode:calcite   (body)
  /s default:sandstone        (foundation/accents)

The included packs are baked for placement origin X=0, Y=8, Z=0.
To place elsewhere, use the web UI and change the three origin fields before copying.
The clipboard always contains absolute integer coordinates; it never contains template offsets.

Packs:
  joke/calcite/calcite1.txt … calcite88.txt
  joke/sandstone/sandstone1.txt … sandstone10.txt
  flat batch_001.txt … batch_097.txt
  ALL_commands_OXOYOZ.txt (absolute baked commands)

Paste ONE complete file into a command block, power it, then continue with the next file.
Every file is <= 9500 bytes and contains only complete /fp set1 /fp set2 /s triples.
Order: calcite files first, then sandstone files.

Totals: 14485 triples, 98 Joke files, 97 flat files.
Max Joke file: 9500 bytes.
